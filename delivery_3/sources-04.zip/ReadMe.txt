Work done by
Andreia Rodrigues
Francisco Queir�s
Miriam Gon�alves

Archive contains the ontology developed, about anime.
Open the OWL file using a compatible program (e.g. Prot�g�).